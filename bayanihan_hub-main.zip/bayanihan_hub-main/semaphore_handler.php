<?php
// Semaphore SMS Handler for Bayanihan Hub

/**
 * Function to send SMS through Semaphore API
 * 
 * @param string|array $recipients Phone number(s) to send SMS to
 * @param string $message The message content to send
 * @param bool $dev_mode Whether to use development mode (default: false)
 * @return array Status of the SMS sending operation
 */
function sendSMS($recipients, $message, $dev_mode = false) {
   
    if (!is_array($recipients)) {
        $recipients = [$recipients];
    }
    
   
    $api_key = '74a30631be247abdb742114051eac139';
    
    
    $sender_name = 'SEMAPHORE'; // Up to 11 characters
    
    $success = 0;
    $failed = 0;
    $results = [];
    
    // Create logs directory for records
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    $log_file = $log_dir . '/semaphore_sms_log.txt';
    
 
    if ($dev_mode) {
        $timestamp = date('Y-m-d H:i:s');
        
    
        $recipients_str = implode(', ', $recipients);
        $log_message = "[$timestamp] DEV MODE - Would send to: $recipients_str\nMessage: $message\n\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
        
      
        foreach ($recipients as $recipient) {
            $cleanNumber = formatPhoneNumber($recipient);
            $success++;
            $results[] = [
                'number' => $recipient,
                'status' => 'simulated_success',
                'dev_mode' => true  // Fixed inconsistency here
            ];
        }
        
        return [
            'success' => $success,
            'failed' => $failed,
            'total' => count($recipients),
            'results' => $results,
            'dev_mode' => true
        ];
    }
    

    foreach ($recipients as $recipient) {
        // Format the phone number for Philippines
        $cleanNumber = formatPhoneNumber($recipient);
        
    
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] SENDING TO: $cleanNumber | MESSAGE: $message\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
        
        try {
        
            $url = 'https://api.semaphore.co/api/v4/messages';
            $parameters = [
                'apikey' => $api_key,
                'number' => $cleanNumber,
                'message' => $message
            ];
            
            // Add sender name if specified
            if (!empty($sender_name)) {
                $parameters['sendername'] = $sender_name;
            }
            
            // Initialize cURL session
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
        
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if ($response !== false && ($http_code >= 200 && $http_code < 300)) {
                $responseData = json_decode($response, true);
                $success++;
                $results[] = [
                    'number' => $recipient,
                    'status' => 'success',
                    'message_id' => isset($responseData['message_id']) ? $responseData['message_id'] : 'unknown'
                ];
                
              
                $message_id = isset($responseData['message_id']) ? $responseData['message_id'] : 'unknown';
                $log_message = "[$timestamp] SUCCESS: $cleanNumber | MESSAGE_ID: {$message_id}\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            } else {
               
                $errorData = json_decode($response, true);
                $errorMessage = '';
                
                if ($errorData && isset($errorData['message'])) {
                    $errorMessage = $errorData['message'];
                } else if ($errorData && isset($errorData['error'])) {
                    $errorMessage = $errorData['error'];
                }
                
                $error = $errorMessage ? "HTTP Code: $http_code - $errorMessage" : "HTTP Code: $http_code";
                
                if (curl_error($ch)) {
                    $error = curl_error($ch);
                }
                
                $failed++;
                $results[] = [
                    'number' => $recipient,
                    'status' => 'failed',
                    'error' => $error
                ];
                
              
                $log_message = "[$timestamp] FAILED: $cleanNumber | ERROR: $error | RESPONSE: $response\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            }
            
            curl_close($ch);
            
        } catch (Exception $e) {
          
            $failed++;
            $results[] = [
                'number' => $recipient,
                'status' => 'failed',
                'error' => $e->getMessage()
            ];
            
     
            $log_message = "[$timestamp] FAILED: $cleanNumber | ERROR: {$e->getMessage()}\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }
        
       
        usleep(300000); 
    }
    
    return [
        'success' => $success,
        'failed' => $failed,
        'total' => count($recipients),
        'results' => $results
    ];
}

/**
 * Format phone number for Semaphore API (Philippines format)
 * 
 * @param string $number Phone number to format
 * @return string Formatted phone number
 */
function formatPhoneNumber($number) {
    // Clean the phone number (remove spaces, dashes, etc.)
    $cleanNumber = preg_replace('/[^0-9+]/', '', $number);
    
    // Format for Philippines
    if (strlen($cleanNumber) == 10 && substr($cleanNumber, 0, 1) == '9') {
        // If number is like 9XXXXXXXXX (just add 0)
        $cleanNumber = '0' . $cleanNumber;
    } else if (strlen($cleanNumber) == 12 && substr($cleanNumber, 0, 3) == '639') {
        // If number is like 639XXXXXXXXX (convert to 09XX format)
        $cleanNumber = '0' . substr($cleanNumber, 2);
    } else if (strlen($cleanNumber) == 13 && substr($cleanNumber, 0, 4) == '+639') {
        // If number is like +639XXXXXXXXX (convert to 09XX format)
        $cleanNumber = '0' . substr($cleanNumber, 3);
    }
    
    // Ensure it starts with 0
    if (substr($cleanNumber, 0, 1) != '0') {
        $cleanNumber = '0' . $cleanNumber;
    }
    
    return $cleanNumber;
}

/**
 * Function to get all resident phone numbers from the database
 * 
 * @param mysqli $conn Database connection
 * @param string $filter Optional filter (e.g., by barangay)
 * @return array Phone numbers of residents
 */
function getResidentPhoneNumbers($conn, $filter = null) {
    $phone_numbers = [];
    
    $query = "SELECT phone_number FROM users WHERE role = 'resident'";
    if ($filter) {
        $query .= " AND barangay = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $filter);
    } else {
        $stmt = $conn->prepare($query);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        if (!empty($row['phone_number'])) {
            $phone_numbers[] = $row['phone_number'];
        }
    }
    
    return $phone_numbers;
}

/**
 * Log SMS sending activity to database
 */
function logSMSActivity($conn, $message_type, $message, $recipients_count, $success_count) {
    // Check if SMS logs table exists
    $table_check = "SHOW TABLES LIKE 'sms_logs'";
    $table_exists = $conn->query($table_check);
    
    // Create table if it doesn't exist
    if ($table_exists->num_rows == 0) {
        $create_table = "CREATE TABLE sms_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            message_type VARCHAR(50) NOT NULL,
            message_content TEXT NOT NULL,
            recipients_count INT NOT NULL DEFAULT 0,
            success_count INT NOT NULL DEFAULT 0,
            sent_by INT,
            sent_date DATETIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $conn->query($create_table);
    }
    
    // Insert log
    $query = "INSERT INTO sms_logs (message_type, message_content, recipients_count, success_count, sent_by, sent_date) 
              VALUES (?, ?, ?, ?, ?, NOW())";
    
    $sent_by = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssiis", $message_type, $message, $recipients_count, $success_count, $sent_by);
    $stmt->execute();
    
    return $stmt->affected_rows > 0;
}

/**
 * Create SMS usage limits table if it doesn't exist
 */
function ensureSMSLimitsTableExists($con) {
    $sql = "CREATE TABLE IF NOT EXISTS sms_usage_limits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        limit_name VARCHAR(50) NOT NULL UNIQUE,
        current_count INT DEFAULT 0,
        max_limit INT DEFAULT 50,
        last_updated DATETIME
    )";
    
    if ($con->query($sql) === TRUE) {
        // Check if we need to insert initial record
        $check = $con->query("SELECT * FROM sms_usage_limits WHERE limit_name = 'total_sms'");
        if ($check->num_rows == 0) {
            // Insert initial record
            $sql = "INSERT INTO sms_usage_limits (limit_name, current_count, max_limit, last_updated) 
                    VALUES ('total_sms', 0, 50, NOW())";
            $con->query($sql);
        }
    }
}

/**
 * Get current SMS usage count and limit
 */
function getSMSUsageInfo($con) {
    ensureSMSLimitsTableExists($con);
    
    // Get current usage
    $result = $con->query("SELECT current_count, max_limit FROM sms_usage_limits WHERE limit_name = 'total_sms'");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    // Default values if query fails
    return ['current_count' => 0, 'max_limit' => 50];
}

/**
 * Increment SMS usage counter
 */
function incrementSMSUsage($con) {
    ensureSMSLimitsTableExists($con);
    $con->query("UPDATE sms_usage_limits SET 
                current_count = current_count + 1,
                last_updated = NOW()
                WHERE limit_name = 'total_sms'");
}

/**
 * Check if SMS limit has been reached
 */
function isOverSMSLimit($con) {
    $usage = getSMSUsageInfo($con);
    return $usage['current_count'] >= $usage['max_limit'];
}
?>