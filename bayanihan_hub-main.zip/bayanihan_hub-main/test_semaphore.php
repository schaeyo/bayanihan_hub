<?php
session_start();
include 'frontEnd/frontEnd/db_connection.php';
include 'semaphore_handler.php';

// Only admins can view this page
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: frontEnd/frontEnd/frontEnd/login/signin.php");
    exit;
}

// Get SMS usage information
$usage = getSMSUsageInfo($con);
$overLimit = $usage['current_count'] >= $usage['max_limit'];

// Handle mode toggle
if (isset($_POST['toggle_mode'])) {
    $_SESSION['sms_dev_mode'] = $_POST['toggle_mode'] === 'dev';
}

// Get dev mode from session or default to false (live mode)
$dev_mode = isset($_SESSION['sms_dev_mode']) ? $_SESSION['sms_dev_mode'] : false;

$message = '';
$error = '';

// Handle test message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['toggle_mode'])) {
    $phone = $_POST['phone'] ?? '';
    $test_message = $_POST['message'] ?? '';
    
    if (!empty($phone) && !empty($test_message)) {
        // Check if over limit before sending (but allow in dev mode)
        if ($overLimit && !$dev_mode) {
            $error = "SMS message limit reached (50 messages). Please visit olfuhost.com to purchase additional messages.";
        } else {
            try {
                // Send test message with Semaphore
                $result = sendSMS($phone, $test_message, $dev_mode);
                
                if ($dev_mode && isset($result['dev_mode'])) {
                    $message = "SMS simulation successful! In development mode, no actual SMS was sent.";
                    $message .= "<br>Would have sent to: $phone";
                    $message .= "<br>Message: $test_message";
                    
                    // Log the activity but don't count against limit in dev mode
                    logSMSActivity($con, 'test', $test_message, 1, 1);
                } else if ($result['success'] > 0) {
                    $message = "SMS sent successfully to $phone!";
                    // Log the activity and increment counter for live mode
                    logSMSActivity($con, 'test', $test_message, 1, 1);
                    incrementSMSUsage($con);
                    
                    // Get updated usage after incrementing
                    $usage = getSMSUsageInfo($con);
                    $overLimit = $usage['current_count'] >= $usage['max_limit'];
                } else {
                    // Display more detailed error information
                    $errorDetails = isset($result['results'][0]['error']) ? $result['results'][0]['error'] : 'Unknown error';
                    $error = "Failed to send SMS. Error: \"{$errorDetails}\"";
                    
                    // Add common error explanations
                    if (strpos($errorDetails, "not a valid") !== false) {
                        $error .= "<br><strong>Tip:</strong> Make sure the phone number is in correct Philippines format (09XX).";
                    } else if (strpos($errorDetails, "API key") !== false) {
                        $error .= "<br><strong>API Error:</strong> The Semaphore API key may be invalid.";
                    }
                }
            } catch (Exception $e) {
                $error = "Error sending SMS: " . $e->getMessage();
            }
        }
    } else {
        $error = "Phone number and message are required.";
    }
}

// Get SMS logs from the database if the table exists
$logs = [];
$table_check = $con->query("SHOW TABLES LIKE 'sms_logs'");
if ($table_check->num_rows > 0) {
    $sql = "SELECT * FROM sms_logs ORDER BY sent_date DESC LIMIT 20";
    $result = $con->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $logs[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semaphore SMS Test - Bayanihan Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        /* Phone UI Styles */
        .phone-container {
            margin: 0 auto;
            width: 280px;
            height: 580px;
            background: #111;
            border-radius: 40px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            padding: 15px;
            position: relative;
            overflow: hidden;
        }
        
        .phone-screen {
            background: #f8f8f8;
            height: 100%;
            width: 100%;
            border-radius: 30px;
            overflow: hidden;
            position: relative;
        }
        
        .phone-header {
            background: #001a4f;
            color: white;
            padding: 10px 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .phone-header h5 {
            margin: 0;
            font-size: 16px;
        }
        
        .phone-time {
            font-size: 14px;
        }
        
        .phone-notch {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 25px;
            background: #111;
            border-bottom-left-radius: 15px;
            border-bottom-right-radius: 15px;
            z-index: 10;
        }
        
        .phone-content {
            padding: 15px;
            height: calc(100% - 50px);
            overflow-y: auto;
        }
        
        .sms-bubble {
            max-width: 80%;
            padding: 10px 15px;
            border-radius: 18px;
            margin-bottom: 10px;
            word-wrap: break-word;
            position: relative;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        .sms-received {
            background: #e5e5ea;
            color: #000;
            border-top-left-radius: 5px;
            float: left;
            clear: both;
        }
        
        .sms-sent {
            background: #007bff;
            color: white;
            border-top-right-radius: 5px;
            float: right;
            clear: both;
        }
        
        .sms-time {
            font-size: 11px;
            opacity: 0.7;
            margin-top: 5px;
            text-align: right;
        }
        
        .phone-footer {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: #fff;
            border-top: 1px solid #ddd;
            padding: 10px;
            display: flex;
        }
        
        .phone-footer input {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 20px;
            padding: 8px 15px;
            font-size: 14px;
            margin-right: 10px;
        }
        
        .phone-footer button {
            background: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .phone-home-indicator {
            position: absolute;
            bottom: 5px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 5px;
            background: #333;
            border-radius: 3px;
        }
        
        .status-bar {
            display: flex;
            justify-content: space-between;
            padding: 5px 15px;
            font-size: 12px;
            background: #f8f8f8;
            color: #333;
        }
        
        .signal-icons i {
            margin-left: 5px;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .preview-label {
            text-align: center;
            margin-bottom: 15px;
            font-weight: bold;
            color: #555;
        }
        
        @media (max-width: 992px) {
            .phone-container {
                margin-top: 30px;
            }
        }
        
        /* Toggle switch styles */
        .form-switch .form-check-input {
            width: 3em;
            height: 1.5em;
            margin-left: 0;
        }
        
        .mode-indicator {
            font-size: 0.875rem;
            font-weight: bold;
            margin-left: 10px;
        }
        
        .mode-dev {
            color: #0d6efd;
        }
        
        .mode-live {
            color: #dc3545;
        }
        
        /* Add progress bar styles */
        .sms-limit-progress {
            height: 10px;
            border-radius: 5px;
        }
        
        .limit-warning {
            color: #dc3545;
            font-weight: bold;
        }
        
        .usage-count {
            font-size: 0.95rem;
            margin-bottom: 5px;
        }
        
        .upgrade-banner {
            background-color: #f8f9fa;
            border-left: 4px solid #0d6efd;
            padding: 15px;
            margin-top: 10px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12 mb-4 d-flex justify-content-between align-items-center">
                <h1>Semaphore SMS Test</h1>
                <a href="frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php" class="btn btn-primary">Back to Dashboard</a>
            </div>
            
            <div class="col-12 mb-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center">
                                <form method="POST" id="modeToggleForm">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" role="switch" id="modeToggle" 
                                            <?php echo $dev_mode ? 'checked' : ''; ?>>
                                        <input type="hidden" name="toggle_mode" id="toggleModeValue" value="<?php echo $dev_mode ? 'dev' : 'live'; ?>">
                                        <label class="form-check-label" for="modeToggle">Development Mode</label>
                                    </div>
                                </form>
                                <span class="mode-indicator <?php echo $dev_mode ? 'mode-dev' : 'mode-live'; ?>">
                                    <?php echo $dev_mode ? '<i class="bi bi-wrench"></i> Testing Mode (No SMS sent)' : '<i class="bi bi-broadcast"></i> Live Mode (Real SMS sent)'; ?>
                                </span>
                            </div>
                            <?php if (!$dev_mode): ?>
                            <div class="badge bg-danger p-2">
                                <i class="bi bi-exclamation-triangle-fill"></i> Sending will use Semaphore credits
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- SMS Usage Counter -->
                        <div class="mt-3">
                            <div class="d-flex justify-content-between align-items-center usage-count">
                                <span>SMS Usage:</span>
                                <span class="<?php echo $usage['current_count'] > ($usage['max_limit'] * 0.8) ? 'limit-warning' : ''; ?>">
                                    <strong><?php echo $usage['current_count']; ?></strong> of <?php echo $usage['max_limit']; ?> messages
                                    <?php if ($overLimit): ?>
                                        <i class="bi bi-exclamation-triangle-fill text-danger"></i>
                                    <?php endif; ?>
                                </span>
                            </div>
                            
                            <div class="progress sms-limit-progress">
                                <?php 
                                    $percentUsed = min(($usage['current_count'] / $usage['max_limit']) * 100, 100);
                                    $progressClass = "bg-success";
                                    
                                    if ($percentUsed > 80) {
                                        $progressClass = "bg-danger";
                                    } else if ($percentUsed > 60) {
                                        $progressClass = "bg-warning";
                                    }
                                ?>
                                <div class="progress-bar <?php echo $progressClass; ?>" 
                                    role="progressbar" 
                                    style="width: <?php echo $percentUsed; ?>%" 
                                    aria-valuenow="<?php echo $usage['current_count']; ?>" 
                                    aria-valuemin="0" 
                                    aria-valuemax="<?php echo $usage['max_limit']; ?>">
                                </div>
                            </div>
                            
                            <?php if ($overLimit && !$dev_mode): ?>
                            <div class="alert alert-danger mt-2">
                                <i class="bi bi-exclamation-octagon-fill"></i> 
                                <strong>SMS limit reached!</strong> You've used all 50 available messages.
                                <div class="upgrade-banner mt-2">
                                    <strong>Need more messages?</strong>
                                    <p class="mb-1">Visit <a href="https://olfuhost.com" target="_blank">olfuhost.com</a> to purchase additional message credits.</p>
                                    <a href="https://olfuhost.com" target="_blank" class="btn btn-sm btn-primary mt-1">
                                        Get More SMS Credits
                                    </a>
                                </div>
                            </div>
                            <?php elseif ($usage['current_count'] > ($usage['max_limit'] * 0.8) && !$dev_mode): ?>
                            <div class="alert alert-warning mt-2">
                                <i class="bi bi-exclamation-triangle-fill"></i> 
                                <strong>Warning:</strong> You are approaching your SMS message limit.
                                <p class="mb-0 mt-1">Visit <a href="https://olfuhost.com" target="_blank">olfuhost.com</a> to purchase additional message credits.</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3>Send Test SMS</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="" id="smsForm">
                            <div class="mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="text" class="form-control" name="phone" id="phoneInput" placeholder="e.g., 09123456789" required
                                       <?php echo ($overLimit && !$dev_mode) ? 'disabled' : ''; ?>>
                                <small class="text-muted">Enter a Philippine number in 09XX format</small>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" name="message" id="messageInput" rows="4" required
                                          <?php echo ($overLimit && !$dev_mode) ? 'disabled' : ''; ?>>Test message from Bayanihan Hub</textarea>
                                <div class="d-flex justify-content-between mt-1">
                                    <small class="text-muted">Type your message above</small>
                                    <small class="text-muted"><span id="charCount">0</span>/160 characters</small>
                                </div>
                            </div>
                            
                            <div class="d-grid">
                                <?php if ($overLimit && !$dev_mode): ?>
                                <a href="https://olfuhost.com" target="_blank" class="btn btn-danger">
                                    <i class="bi bi-lock-fill me-1"></i> Get More SMS Credits
                                </a>
                                <p class="text-center text-danger mt-2">
                                    <i class="bi bi-info-circle"></i> SMS sending locked - limit reached
                                </p>
                                <?php else: ?>
                                <button type="button" id="sendSmsButton" class="btn btn-primary">
                                    Send Test SMS
                                </button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header bg-secondary text-white">
                        <h3>Recent SMS Logs</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($logs)): ?>
                            <div class="alert alert-info">No SMS logs found.</div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Recipients</th>
                                            <th>Success</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td><?= $log['sent_date'] ?></td>
                                            <td><?= $log['message_type'] ?></td>
                                            <td><?= $log['recipients_count'] ?></td>
                                            <td>
                                                <?php if ($log['success_count'] == $log['recipients_count']): ?>
                                                    <span class="badge bg-success">All Sent</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning">
                                                        <?= $log['success_count'] ?>/<?= $log['recipients_count'] ?>
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="preview-label">SMS Preview</div>
                <div class="phone-container">
                    <div class="phone-notch"></div>
                    <div class="phone-screen">
                        <div class="status-bar">
                            <div class="phone-time" id="phoneTime">9:41 AM</div>
                            <div class="signal-icons">
                                <i class="bi bi-reception-4"></i>
                                <i class="bi bi-wifi"></i>
                                <i class="bi bi-battery-full"></i>
                            </div>
                        </div>
                        <div class="phone-header">
                            <h5 id="recipientName">Recipient</h5>
                            <div>
                                <i class="bi bi-telephone-fill"></i>
                                <i class="bi bi-three-dots-vertical ms-2"></i>
                            </div>
                        </div>
                        <div class="phone-content" id="smsContent">
                            <div class="sms-bubble sms-received">
                                Hello! How can Bayanihan Hub help you today?
                                <div class="sms-time">9:30 AM</div>
                            </div>
                            <div class="sms-bubble sms-sent" id="previewSMS">
                                Test message from Bayanihan Hub
                                <div class="sms-time" id="currentTime">Now</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Handle success and error messages with SweetAlert
            <?php if ($message): ?>
                Swal.fire({
                    title: 'Success',
                    html: '<?= $message ?>',
                    icon: 'success'
                });
            <?php endif; ?>
            
            <?php if ($error): ?>
                Swal.fire({
                    title: 'Error',
                    html: '<?= $error ?>',
                    icon: 'error'
                });
            <?php endif; ?>
            
            // Update current time on phone UI
            function updateTime() {
                const now = new Date();
                document.getElementById('phoneTime').textContent = now.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                document.getElementById('currentTime').textContent = 'Now';
            }
            updateTime();
            setInterval(updateTime, 60000);
            
            // Update SMS preview as user types
            const messageInput = document.getElementById('messageInput');
            const previewSMS = document.getElementById('previewSMS');
            const charCount = document.getElementById('charCount');
            const phoneInput = document.getElementById('phoneInput');
            const recipientName = document.getElementById('recipientName');
            const smsForm = document.getElementById('smsForm');
            
            // Initial character count
            charCount.textContent = messageInput.value.length;
            
            messageInput.addEventListener('input', function() {
                previewSMS.innerHTML = this.value + '<div class="sms-time" id="currentTime">Now</div>';
                charCount.textContent = this.value.length;
                
                // Add visual indication if message exceeds 160 characters (standard SMS limit)
                if (this.value.length > 160) {
                    charCount.classList.add('text-danger');
                } else {
                    charCount.classList.remove('text-danger');
                }
            });
            
            phoneInput.addEventListener('input', function() {
              
                let displayName = this.value.trim();
                if (displayName === '') {
                    displayName = 'Recipient';
                }
                recipientName.textContent = displayName;
            });
            
           
            const modeToggle = document.getElementById('modeToggle');
            const toggleModeValue = document.getElementById('toggleModeValue');
            const modeToggleForm = document.getElementById('modeToggleForm');
            
            modeToggle.addEventListener('change', function() {
                const newMode = this.checked ? 'dev' : 'live';
                
           
                if (newMode === 'live') {
                    <?php if ($overLimit): ?>
                    // Warn about being over limit when switching to live mode
                    Swal.fire({
                        title: 'SMS Limit Reached',
                        html: `
                            <div class="alert alert-danger">
                                <i class="bi bi-exclamation-triangle-fill"></i> You have reached your limit of 50 SMS messages.
                            </div>
                            <p>Live mode will be enabled, but you won't be able to send messages until you purchase more credits.</p>
                            <p>Visit <a href="https://olfuhost.com" target="_blank">olfuhost.com</a> to purchase additional message credits.</p>
                        `,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#dc3545',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Continue to Live Mode',
                        cancelButtonText: 'Stay in Dev Mode'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            toggleModeValue.value = 'live';
                            modeToggleForm.submit();
                        } else {
                            modeToggle.checked = true;
                        }
                    });
                    <?php else: ?>
                    // Normal live mode warning
                    Swal.fire({
                        title: 'Switch to Live Mode?',
                        html: '<div class="alert alert-warning"><i class="bi bi-exclamation-triangle-fill"></i> In Live Mode, real SMS messages will be sent and Semaphore credits will be used.</div>',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#dc3545',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Yes, Enable Live Mode',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            toggleModeValue.value = 'live';
                            modeToggleForm.submit();
                        } else {
                            modeToggle.checked = true;
                        }
                    });
                    <?php endif; ?>
                } else {
                   
                    toggleModeValue.value = 'dev';
                    modeToggleForm.submit();
                }
            });
            
            
            document.getElementById('sendSmsButton')?.addEventListener('click', function() {
                <?php if ($overLimit && !$dev_mode): ?>
                // Double-check that we're over the limit
                Swal.fire({
                    title: 'SMS Limit Reached',
                    html: `
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-triangle-fill"></i> You've used all 50 available messages.
                        </div>
                        <div class="text-center mt-3">
                            <p>Visit <a href="https://olfuhost.com" target="_blank">olfuhost.com</a> to purchase additional SMS credits.</p>
                            <a href="https://olfuhost.com" target="_blank" class="btn btn-primary mt-2">
                                Get More SMS Credits
                            </a>
                        </div>
                    `,
                    icon: 'error',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                });
                return;
                <?php endif; ?>
                
                // First validate the form
                if (!smsForm.checkValidity()) {
                    smsForm.reportValidity();
                    return;
                }
                
                const phone = phoneInput.value;
                const message = messageInput.value;
                
           
                if (!<?php echo $dev_mode ? 'true' : 'false'; ?>) {
                    Swal.fire({
                        title: 'Send Real SMS?',
                        html: `
                            <div class="alert alert-warning">
                                <i class="bi bi-exclamation-triangle-fill"></i> This will send a real SMS message using Semaphore credits.
                            </div>
                            <p><strong>Recipient:</strong> ${phone}</p>
                            <p><strong>Message:</strong> ${message}</p>
                            <p><small>You have used <?= $usage['current_count'] ?> of <?= $usage['max_limit'] ?> available messages.</small></p>
                        `,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#0d6efd',
                        cancelButtonColor: '#6c757d',
                        confirmButtonText: 'Yes, Send SMS',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            smsForm.submit();
                        }
                    });
                } else {
                    
                    smsForm.submit();
                }
            });
            
    
            smsForm.addEventListener('submit', function() {
                const message = messageInput.value;
                if (message) {
                    const newBubble = document.createElement('div');
                    newBubble.className = 'sms-bubble sms-sent';
                    newBubble.innerHTML = message + '<div class="sms-time">Now</div>';
                    
                    const smsContent = document.getElementById('smsContent');
                    smsContent.appendChild(newBubble);
                    smsContent.scrollTop = smsContent.scrollHeight;
                }
            });
        });
    </script>
</body>
</html>