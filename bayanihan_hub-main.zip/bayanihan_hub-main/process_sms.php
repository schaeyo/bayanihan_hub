<?php
session_start();
include 'frontEnd/frontEnd/db_connection.php';
include 'semaphore_handler.php';

// Only allow POST requests from authenticated admins
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: frontEnd/frontEnd/frontEnd/login/signin.php");
    exit;
}

// Initialize variables
$message_type = $_POST['message_type'] ?? '';
$send_sms = isset($_POST['send_sms']) ? (int)$_POST['send_sms'] : 1; // Default to sending SMS

// Create notification message based on message type
$sms_message = "";
$title = "";

try {
    if ($message_type === 'utility') {
        // Process utility interruption
        $type = $_POST['type'] ?? '';
        $date = $_POST['date'] ?? '';
        $time = $_POST['time'] ?? '';
        $duration = $_POST['duration'] ?? '';
        $reason = $_POST['reason'] ?? '';
        
        // Check required fields for utility interruptions
        if (empty($type) || empty($date) || empty($time) || empty($duration) || empty($reason)) {
            $_SESSION['error'] = "All fields are required for utility interruptions.";
            header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php?status=error");
            exit;
        }
        
        // Format date and time for display
        $formatted_date = date("F j, Y", strtotime($date));
        $formatted_time = date("g:i A", strtotime($time));
        
        // Create utility message
        $sms_message = "NOTICE: $type interruption scheduled on $formatted_date at $formatted_time for approximately $duration. $reason";
        $title = "$type Interruption Notification";
        
    } else if ($message_type === 'emergency') {
        // Process emergency message
        $emergency_message = $_POST['emergency_message'] ?? '';
        
        // Check required field for emergency
        if (empty($emergency_message)) {
            $_SESSION['error'] = "Emergency message is required.";
            header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php?status=error");
            exit;
        }
        
        // Create emergency message
        $sms_message = "EMERGENCY ALERT: $emergency_message";
        $title = "EMERGENCY ALERT";
        
    } else {
        $_SESSION['error'] = "Invalid message type: $message_type";
        header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php?status=error");
        exit;
    }

    // Insert notification into database
    $sql = "INSERT INTO announcements (title, description, created_at, category) 
        VALUES (?, ?, NOW(), 'Public Notice')";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sss", $title, $sms_message, $message_type);
    $stmt->execute();
    
    // Save result in session
    $_SESSION['notification_saved'] = true;
    
    // Send SMS if requested
    if ($send_sms) {
        // Get dev mode from session or default to false
        $dev_mode = isset($_SESSION['sms_dev_mode']) ? $_SESSION['sms_dev_mode'] : false;
        
        // Get all resident phone numbers
        $query = "SELECT phone_number FROM users WHERE phone_number IS NOT NULL AND phone_number != ''";
        $result = $con->query($query);
        
        $phone_numbers = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $phone_numbers[] = $row['phone_number'];
            }
        }
        
        // Check if we have recipients
        if (!empty($phone_numbers)) {
            // Check if over limit before sending (but allow in dev mode)
            $usage = getSMSUsageInfo($con);
            $overLimit = $usage['current_count'] >= $usage['max_limit'];
            
            if ($overLimit && !$dev_mode) {
                $_SESSION['sms_error'] = "SMS limit reached. Please visit olfuhost.com to purchase additional messages.";
            } else {
                $sent_count = 0;
                $failed_count = 0;
                $total_recipients = count($phone_numbers);
                
                // For bulk messages, we'll log one activity but note the recipient count
                if ($dev_mode) {
                    // In dev mode, simulate success but don't actually send
                    $_SESSION['sms_sent'] = true;
                    $_SESSION['sms_dev_mode'] = true;
                    $_SESSION['sms_success'] = $total_recipients;
                    $_SESSION['sms_failed'] = 0;
                    $_SESSION['sms_total'] = $total_recipients;
                    
                    // Log the activity but don't count against limit
                    logSMSActivity($con, $message_type, $sms_message, $total_recipients, $total_recipients);
                    
                    // Log the simulation to a file
                    $log_dir = __DIR__ . '/logs';
                    if (!is_dir($log_dir)) {
                        mkdir($log_dir, 0755, true);
                    }
                    $log_file = $log_dir . '/semaphore_sms_log.txt';
                    $log_message = "[" . date("Y-m-d H:i:s") . "] DEV MODE - Would send to: " . count($phone_numbers) . " recipients\n";
                    $log_message .= "Message: $sms_message\n\n";
                    file_put_contents($log_file, $log_message, FILE_APPEND);
                } else {
                    // In production, send actual SMS
                    // For real implementation, you may want to batch these to avoid timeouts
                    foreach ($phone_numbers as $phone) {
                        $result = sendSMS($phone, $sms_message, $dev_mode);
                        
                        if (isset($result['success']) && $result['success'] > 0) {
                            $sent_count++;
                        } else {
                            $failed_count++;
                        }
                    }
                    
                    // Log SMS activity
                    logSMSActivity($con, $message_type, $sms_message, $total_recipients, $sent_count);
                    
                    // Increment the counter for each successful message
                    for ($i = 0; $i < $sent_count; $i++) {
                        incrementSMSUsage($con);
                    }
                    
                    // Store results in session
                    $_SESSION['sms_sent'] = true;
                    $_SESSION['sms_success'] = $sent_count;
                    $_SESSION['sms_failed'] = $failed_count;
                    $_SESSION['sms_total'] = $total_recipients;
                }
            }
        } else {
            $_SESSION['sms_error'] = "No recipient phone numbers found in the database.";
        }
    }
    
    // Redirect back with success status
    header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php?status=success");
    exit;
    
} catch (Exception $e) {
    $_SESSION['error'] = "Error: " . $e->getMessage();
    header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php?status=error");
    exit;
}
?>