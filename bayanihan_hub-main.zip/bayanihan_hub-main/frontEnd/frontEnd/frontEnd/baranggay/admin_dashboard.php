<?php
session_start();
include '../../db_connection.php';

// Get user ID from session
$user_id = $_SESSION['user_id'] ?? null;

// Fetch user details from the database
$user = null;
if ($user_id) {
    $query = "SELECT first_name, last_name, email, house_address, phone_number FROM users WHERE user_id = ?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
}

// Fetch total counts for dashboard cards
$totalResidents = 0;
$totalRequests = 0;
$totalEmergencies = 0;
$totalOfficials = 0;

// Fetch total residents
$residentQuery = "SELECT COUNT(*) AS total FROM users WHERE role = 'resident'";
$residentResult = $con->query($residentQuery);
if ($residentResult) {
    $totalResidents = $residentResult->fetch_assoc()['total'];
}

// Fetch total requests
$requestQuery = "SELECT COUNT(*) AS total FROM requests";
$requestResult = $con->query($requestQuery);
if ($requestResult) {
    $totalRequests = $requestResult->fetch_assoc()['total'];
}

// Fetch total emergencies
$emergencyQuery = "SELECT COUNT(*) AS total FROM emergency_reports";
$emergencyResult = $con->query($emergencyQuery);
if ($emergencyResult) {
    $totalEmergencies = $emergencyResult->fetch_assoc()['total'];
}

// Fetch total barangay officials
$officialsQuery = "SELECT COUNT(*) AS total FROM users WHERE role = 'admin'";
$officialsResult = $con->query($officialsQuery);
if ($officialsResult) {
    $totalOfficials = $officialsResult->fetch_assoc()['total'];
}

// Fetch residents
$residentsQuery = "SELECT first_name, last_name, email, house_address, phone_number FROM users WHERE role = 'resident'";
$residentsResult = $con->query($residentsQuery);
$residents = $residentsResult->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bayanihan Hub - Dashboard</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css"
    />
    <!-- SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="style.d.css" />
    <link rel="stylesheet" href="../public/css/home.css" />
    <style>
      html {
        height: 100%;
      }
      body {
        min-height: 100%;
        display: flex;
        flex-direction: column;
      }
      main {
        flex: 1;
      }
      footer {
        margin-top: auto;
        background: #130d33;
      }
      .residents-table-container {
        max-height: 300px;
        overflow-y: auto;
      }
      .cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
  margin-top: 30px;
  padding: 0 20px;
}

.card {
  padding: 25px;
  color: white;
  border-radius: 20px;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  cursor: pointer;
  text-align: center;
}

.card h2 {
  font-size: 2.5rem;
  margin-bottom: 10px;
}

.card p {
  font-size: 1.1rem;
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.2);
}

.card.blue {
  background: linear-gradient(to right, #007bff, #0056b3);
}
.card.green {
  background: linear-gradient(to right, #28a745, #218838);
}
.card.yellow {
  background: linear-gradient(to right, #ffc107, #e0a800);
  color: #000;
}
.card.red {
  background: linear-gradient(to right, #dc3545, #c82333);
}

main section {
  margin: 40px 20px;
  padding: 20px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.08);
}

.residents-table-container {
  overflow-x: auto;
}

.table {
  margin-top: 15px;
}

.table thead {
  background-color: #001a4f;
  color: white;
}

.table tbody tr:hover {
  background-color: #f1f1f1;
  transition: 0.3s;
}
      
    </style>
  </head>
  <body>
    <!-- Sidebar -->
<div class="sidebar" id="sidebar">
      <div class="mt-5">
        <a href="accountInfo.php" class="active p-2"><i class="bi bi-person-circle mx-3"></i>Hi, <?php echo htmlspecialchars($user['first_name']); ?></a>
        <a href="admin_dashboard.php"><i class="bi bi-house-door"></i> Home</a>
        <a href="data-analytics.php"><i class="bi bi-graph-up"></i> Data Analytics</a> 
        <a href="appointmentRequest.php"><i class="bi bi-calendar-check"></i> Appointment Requests</a>
        <a href="reviewRequest.php"><i class="bi bi-file-earmark-check"></i> Review Request</a>
        <a href="manageUsers.php"><i class="bi bi-people"></i>  Manage Users and Roles</a>
        <a href="announceManage.php"><i class="bi bi-megaphone"></i> Announcement Management</a>
        <a href="emergencyResponse.php"><i class="bi bi-exclamation-triangle"></i> Emergency Response Coordination</a>
        <a href="viewFeedback.php"><i class="bi bi-chat-dots"></i> View Feedback</a>
        <a href="dbManage.php"><i class="bi bi-database"></i> Data Management</a>
        <a href="../login/signin.php" data-bs-toggle="modal" data-bs-target="#logoutModal"><i class="bi bi-box-arrow-right"></i> Logout</a>
      </div>
    </div>

        <!-- Logout Confirmation Modal -->
        <div class="modal fade" id="logoutModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-body text-center">
            <h3>Are you sure you want to log out?</h3>
          </div>
          <div class="modal-footer d-flex justify-content-center">
            <button
              type="button"
              class="btn btn-secondary px-4 text-center"
              data-bs-dismiss="modal"
            >
              Cancel
            </button>
            <a
              href="../login/signin.php"
              class="btn btn-danger text-center px-4 ms-3"
            >
              Yes, Logout
            </a>
          </div>
        </div>
      </div>
    </div>
<!-- Toggle Button -->
<button class="toggle-btn" id="toggleBtn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button>

<!-- Header -->
<div class="text-light" style="background-color: #001a4f">
  <div class="container brand-header">
    <img src="../media/logo2.png" alt="Bayanihan Hub Logo" width="90" height="90" style="border-radius: 50%;" />
    <h3 class="mx-3 mt-2">Bayanihan Hub</h3>
  </div>
</div>

    <!-- Main Content -->
    <main>
      <section class="cards">
        <div class="card blue" onclick="showCardInfo('residents')">
        <h2 class="counter" id="totalResidents"><?php echo $totalResidents; ?></h2>
          <p>Total Residents</p>
        </div>
        <div class="card green" onclick="showCardInfo('requests')">
          <h2 id="totalRequests"><?php echo $totalRequests; ?></h2>
          <p>Total Requests</p>
        </div>
        <div class="card yellow" onclick="showCardInfo('emergencies')">
          <h2 id="totalEmergencies"><?php echo $totalEmergencies; ?></h2>
          <p>Total Emergencies</p>
        </div>
        <div class="card red" onclick="showCardInfo('officials')">
          <h2 id="totalOfficials"><?php echo $totalOfficials; ?></h2>
          <p>Barangay Officials</p>
        </div>
      </section>

      <!-- Add this after the dashboard heading -->
<div class="row">
  <div class="col-12">
    <?php if (isset($_GET['status']) && $_GET['status'] === 'success'): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong>
        <?php if (isset($_SESSION['notification_saved'])): ?>
          Notification has been saved.
          <?php unset($_SESSION['notification_saved']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['sms_sent'])): ?>
          <?php if (isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode']): ?>
            SMS would have been sent to <?= $_SESSION['sms_total'] ?? 0 ?> recipients (Development Mode).
          <?php else: ?>
            SMS sent successfully to <?= $_SESSION['sms_success'] ?? 0 ?> recipients.
            <?php if (isset($_SESSION['sms_failed']) && $_SESSION['sms_failed'] > 0): ?>
              (<?= $_SESSION['sms_failed'] ?> failed)
            <?php endif; ?>
          <?php endif; ?>
          <?php unset($_SESSION['sms_sent'], $_SESSION['sms_success'], $_SESSION['sms_failed'], $_SESSION['sms_total']); ?>
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['status']) && $_GET['status'] === 'error'): ?>
  <div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Error!</strong>
    <?php if (isset($_SESSION['error'])): ?>
      <?= $_SESSION['error'] ?>
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['sms_error'])): ?>
      <?= $_SESSION['sms_error'] ?>
      <?php unset($_SESSION['sms_error']); ?>
    <?php endif; ?> <!-- This was the missing endif tag -->
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
<?php endif; ?>
  </div>
</div>

      <!-- Profile Section -->
      <section>
  <h3 class="mb-4">Profile</h3>
  <div class="card p-4 shadow-sm text-black">
    <div class="row">
      <div class="col-md-6 mb-2">
        <strong>Name:</strong> <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
      </div>
      <div class="col-md-6 mb-2">
        <strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?>
      </div>
      <div class="col-md-6 mb-2">
        <strong>House Address:</strong> <?php echo htmlspecialchars($user['house_address']); ?>
      </div>
      <div class="col-md-6 mb-2">
        <strong>Phone Number:</strong> <?php echo htmlspecialchars($user['phone_number']); ?>
      </div>
    </div>
  </div>
</section>

      <!-- Residents Section -->
      <section class="mt-5">
        <h3>Residents</h3>
        <div class="residents-table-container">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>House Address</th>
                <th>Phone Number</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($residents as $resident): ?>
                <tr>
                  <td><?php echo htmlspecialchars($resident['first_name']); ?></td>
                  <td><?php echo htmlspecialchars($resident['last_name']); ?></td>
                  <td><?php echo htmlspecialchars($resident['email']); ?></td>
                  <td><?php echo htmlspecialchars($resident['house_address']); ?></td>
                  <td><?php echo htmlspecialchars($resident['phone_number']); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </section>

      <!-- Replace the Utility Interruption form -->
<section class="mt-5">
  <h3>Send Utility Interruption Notifications</h3>
  <div class="card p-4">
    <form id="notificationForm" method="POST" action="process_utility_sms.php">
      <input type="hidden" name="message_type" value="utility">
      
      <div class="row mb-3">
        <div class="col-md-6">
          <label class="form-label">Type of Interruption *</label>
          <select class="form-control" name="type" id="interruptType" required>
            <option value="Electric">Electric</option>
            <option value="Water">Water</option>
            <option value="Internet">Internet</option>
            <option value="Road Closure">Road Closure</option>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label">Date *</label>
          <input type="date" class="form-control" name="date" id="interruptDate" required>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-md-6">
          <label class="form-label">Time *</label>
          <input type="time" class="form-control" name="time" id="interruptTime" required>
        </div>
        <div class="col-md-6">
          <label class="form-label">Duration *</label>
          <input type="text" class="form-control" name="duration" id="interruptDuration" placeholder="e.g., 2 hours" required>
        </div>
      </div>
      <div class="row mb-3">
        <div class="col-12">
       
          <label class="form-label">Reason/Additional Details *</label>
          <textarea class="form-control" name="reason" id="interruptReason" rows="3" required></textarea>
        </div>
      </div>
      <div class="form-check mb-3">
        <input class="form-check-input" type="checkbox" name="send_sms" value="1" id="sendSmsCheck" checked>
        <label class="form-check-label" for="sendSmsCheck">
        <small class="text-muted">Send as SMS to all residents (default checked)</small>
        </label>
      </div>
      <button type="submit" class="btn btn-primary">Send Notification</button>
    </form>
  </div>
</section>

<!-- Add after the beginning of the first form section -->
<section class="mt-5">
  <h3>SMS Notification Settings</h3>
  <div class="card p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center">
      <div class="d-flex align-items-center">
        <form method="POST" id="dashboardModeToggleForm" action="../../../../process_sms_mode.php">
          <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="dashboardModeToggle" 
                <?php echo isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? 'checked' : ''; ?>>
            <input type="hidden" name="toggle_mode" id="dashboardToggleModeValue" 
                value="<?php echo isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? 'dev' : 'live'; ?>">
            <label class="form-check-label" for="dashboardModeToggle">SMS Development Mode</label>
          </div>
        </form>
        <span class="mode-indicator ms-2 <?php echo isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? 'text-primary' : 'text-danger'; ?>">
          <?php echo isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? 
              '<i class="bi bi-wrench"></i> Testing Mode (No SMS sent)' : 
              '<i class="bi bi-broadcast"></i> Live Mode (Real SMS sent)'; ?>
        </span>
      </div>
      <?php if (!isset($_SESSION['sms_dev_mode']) || !$_SESSION['sms_dev_mode']): ?>
      <div class="badge bg-danger p-2">
        <i class="bi bi-exclamation-triangle-fill"></i> Sending will use Semaphore credits
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- Emergency SMS Section -->
<section class="mt-5">
  <h3>Emergency SMS Broadcast</h3>
  <div class="card p-4">
    <form id="emergencyForm" method="POST" action="process_emergency_sms.php">
      <input type="hidden" name="message_type" value="emergency">
      <input type="hidden" name="type" value="Emergency">
      <input type="hidden" name="date" value="<?= date('Y-m-d') ?>">
      <input type="hidden" name="time" value="<?= date('H:i') ?>">
      <input type="hidden" name="duration" value="Until further notice">
      <input type="hidden" name="send_sms" value="1">
      
      <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill"></i> <strong>Emergency Broadcasts</strong> will immediately send SMS to all residents. Use this only for urgent community notifications.
      </div>
      
      <div class="row mb-3">
        <div class="col-md-12">
          <label class="form-label">Emergency Templates</label>
          <select class="form-control mb-2" id="emergencyTemplateSelector">
            <option value="">-- Select a template or write your own --</option>
            <option value="EVACUATION ALERT: Please evacuate immediately from [AREA] due to [REASON]. Proceed to designated evacuation centers.">Evacuation Notice</option>
            <option value="WEATHER WARNING: [TYPE] warning in effect. Secure your homes and stay indoors until further notice.">Weather Warning</option>
            <option value="FIRE ALERT: Fire reported at [LOCATION]. Please avoid the area and follow instructions from emergency personnel.">Fire Alert</option>
            <option value="MEDICAL EMERGENCY: Medical assistance needed at [LOCATION]. If you have medical training, please assist if safe to do so.">Medical Emergency</option>
            <option value="SECURITY ALERT: [INCIDENT TYPE] reported in [AREA]. Please stay vigilant and report suspicious activities to authorities.">Security Alert</option>
          </select>
          
          <label class="form-label">Emergency Message *</label>
          <textarea class="form-control" name="reason" id="emergencyMessageField" rows="3" placeholder="Enter emergency details that will be sent to all residents" required></textarea>
          <small class="text-muted">Select a template and customize it with specific details as needed.</small>
        </div>
      </div>
      
      <div class="text-end">
        <button type="button" onclick="confirmEmergencyBroadcast(document.getElementById('emergencyForm'))" class="btn btn-danger">Send Emergency Broadcast</button>
      </div>
    </form>
  </div>
</section>

    </main>
    <style>
      .sidebar {
        background-color: #001a4f; /* Sidebar color */
        color: white;
        height: 100vh;
        padding: 20px;
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        overflow-y: auto;
      }
      .sidebar a {
        color: white;
        text-decoration: none;
        display: block;
        margin: 10px 0;
        padding: 10px;
        border-radius: 5px;
      }
      .sidebar a:hover {
        background-color: #001a4f; /* Darker shade for hover/active */
      }
      .toggle-btn:hover {
        background-color: #001a4f;
      }
      .appointment-form {
        background-color: #f8f8f8;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 4px 6px rgba(182, 37, 37, 0.1);
      }
      .form-label {
        font-weight: bold;
      }
      .btn-submit {
        background-color: #001a4f;
        color: white;
      }
      .btn-submit:hover {
        background-color: #090549;
      }
    </style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Custom SweetAlert handlers -->
<script src="../public/js/sweet-alerts.js"></script>
    <footer class=" text-light py-4 mt-5">
  <div class="container">
    <div class="row">
      <!-- Barangay Info -->
      <div class="col-md-3">
        <img src="../media/logo.png" alt="Logo" width="60" height="60" class="mb-2 rounded-circle">
        <h5>Barangay Information</h5>
        <p><strong>Barangay Name, Province</strong></p>
        <p><strong>Office Hours:</strong><br>Monday - Friday: 8:00 AM - 5:00 PM</p>
        <p><strong>Contact Info:</strong><br>Email: info@barangay.gov.ph</p>
      </div>

      <!-- Quick Links -->
      <div class="col-md-3">
        <h5>Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="admin_dashboard.php" class="text-light text-decoration-none">Home</a></li>
          <li><a href="data-analytics.php" class="text-light text-decoration-none">Data Analytics</a></li>
          <li><a href="reviewRequest.php" class="text-light text-decoration-none">Review Request</a></li>
          <li><a href="manageUsers.php" class="text-light text-decoration-none">Manage Users</a></li>
          <li><a href="announceManage.php" class="text-light text-decoration-none">Announcements</a></li>
          <li><a href="emergencyResponse.php" class="text-light text-decoration-none">Emergency Response</a></li>
          <li><a href="dbManage.php" class="text-light text-decoration-none">Data Management</a></li>
        </ul>
      </div>

      <!-- Account Links -->
      <div class="col-md-3">
        <h5>My Account</h5>
        <ul class="list-unstyled">
          <li><a href="accountInfo.php" class="text-light text-decoration-none">Profile</a></li>
          <li><a href="../login/signin.php" class="text-light text-decoration-none">Logout</a></li>
        </ul>
      </div>

      <!-- Social Links -->
      <div class="col-md-3">
        <h5>Follow Us</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light text-decoration-none"><i class="bi bi-globe me-1"></i>Official Website</a></li>
          <li><a href="#" class="text-light text-decoration-none"><i class="bi bi-facebook me-1"></i>Facebook</a></li>
          <li><a href="#" class="text-light text-decoration-none"><i class="bi bi-twitter me-1"></i>Twitter</a></li>
        </ul>
      </div>
    </div>

    <hr class="border-secondary my-3" />
    <p class="text-center mb-0">&copy; <?php echo date("Y"); ?> Bayanihan Hub. All Rights Reserved.</p>
  </div>
</footer>
    <script>
      function toggleSidebar() {
        const sidebar = document.getElementById("sidebar");
        sidebar.classList.toggle("active");
      }

      // Remove the old showInfo function
      // function showInfo(type) {
      //   alert("Showing information for: " + type);
      // }
    </script>
    <script>
  document.querySelectorAll('.counter').forEach(el => {
    let finalValue = parseInt(el.innerText);
    let count = 0;
    let increment = finalValue / 40;
    let interval = setInterval(() => {
      count += increment;
      if (count >= finalValue) {
        el.innerText = finalValue;
        clearInterval(interval);
      } else {
        el.innerText = Math.floor(count);
      }
    }, 20);
  });
</script>
    <script src="../public/js/toggle.js"></script>
    <div class="fixed-bottom p-3 text-end">
    <a href="../../../../test_semaphore.php" class="btn btn-info">
        <i class="bi bi-phone"></i> Test Semaphore SMS
    </a>
</div>
<script>
  // Template functionality for Utility Interruption messages
  document.addEventListener('DOMContentLoaded', function() {
    const templateSelector = document.getElementById('utilityTemplateSelector');
    const reasonField = document.getElementById('reasonField');
    const typeSelect = document.getElementById('interruptType');
    const dateInput = document.getElementById('interruptDate');
    const timeInput = document.getElementById('interruptTime');
    const durationInput = document.getElementById('interruptDuration');
    
    if(templateSelector && reasonField) {
      templateSelector.addEventListener('change', function() {
        if(this.value) {
          // Get selected form values
          const type = typeSelect ? typeSelect.value : '';
          const date = dateInput ? formatDate(dateInput.value) : '';
          const time = timeInput ? formatTime(timeInput.value) : '';
          const duration = durationInput ? durationInput.value : '';
          
          // Replace placeholders with actual values
          let messageText = this.value
            .replace('{type}', type)
            .replace('{date}', date)
            .replace('{time}', time)
            .replace('{duration}', duration);
          
          reasonField.value = messageText;
        }
      });
      
      // Update message when form fields change
      const formFields = [typeSelect, dateInput, timeInput, durationInput];
      formFields.forEach(field => {
        if(field) {
          field.addEventListener('change', function() {
            if(templateSelector.value) {
              templateSelector.dispatchEvent(new Event('change'));
            }
          });
        }
      });
    }
    
    // Template functionality for Emergency messages
    const emergencyTemplateSelector = document.getElementById('emergencyTemplateSelector');
    const emergencyMessageField = document.getElementById('emergencyMessageField');
    
    if(emergencyTemplateSelector && emergencyMessageField) {
      emergencyTemplateSelector.addEventListener('change', function() {
        if(this.value) {
          emergencyMessageField.value = this.value;
          
          // Highlight placeholders for easy editing
          const message = emergencyMessageField.value;
          const highlightedMessage = message.replace(/\[(.*?)\]/g, '[ $1 ]');
          emergencyMessageField.value = highlightedMessage;
        }
      });
    }
    
    // Helper function to format date as "Month Day, Year"
    function formatDate(dateString) {
      if(!dateString) return '';
      
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric'
      });
    }
    
    // Helper function to format time from 24h to 12h format
    function formatTime(timeString) {
      if(!timeString) return '';
      
      const [hours, minutes] = timeString.split(':');
      const hour = parseInt(hours);
      const ampm = hour >= 12 ? 'PM' : 'AM';
      const hour12 = hour % 12 || 12;
      
      return `${hour12}:${minutes} ${ampm}`;
    }
  });
</script>
<script>
      // Check URL parameters to show success message with SweetAlert
      document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const status = urlParams.get('status');
        
        if (status === 'success') {
          // Get SMS data from PHP session (passed as JSON)
          const smsData = {
            sms_sent: <?= isset($_SESSION['sms_sent']) ? 'true' : 'false' ?>,
            sms_dev_mode: <?= isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? 'true' : 'false' ?>,
            sms_success: <?= $_SESSION['sms_success'] ?? 0 ?>,
            sms_failed: <?= $_SESSION['sms_failed'] ?? 0 ?>,
            sms_total: <?= $_SESSION['sms_total'] ?? 0 ?>
          };
          
          showNotificationSuccess(smsData);
          
          // Clear session variables
          <?php
            unset($_SESSION['sms_sent']);
            unset($_SESSION['sms_success']);
            unset($_SESSION['sms_failed']);
            unset($_SESSION['sms_total']);
            unset($_SESSION['sms_dev_mode']);
          ?>
        }
        
        // Update logout links to use SweetAlert
        const logoutLinks = document.querySelectorAll('a[data-bs-target="#logoutModal"]');
        logoutLinks.forEach(link => {
          link.removeAttribute('data-bs-toggle');
          link.removeAttribute('data-bs-target');
          link.addEventListener('click', function(e) {
            e.preventDefault();
            showLogoutConfirmation('../login/signin.php');
          });
        });
      });
    </script>
    <script>
  // Mode toggle handler for dashboard
  document.addEventListener('DOMContentLoaded', function() {
    const dashboardModeToggle = document.getElementById('dashboardModeToggle');
    const dashboardToggleModeValue = document.getElementById('dashboardToggleModeValue');
    const dashboardModeToggleForm = document.getElementById('dashboardModeToggleForm');
    
    if (dashboardModeToggle) {
      dashboardModeToggle.addEventListener('change', function() {
        const newMode = this.checked ? 'dev' : 'live';
        
        if (newMode === 'live') {
          Swal.fire({
            title: 'Switch to Live Mode?',
            html: '<div class="alert alert-warning"><i class="bi bi-exclamation-triangle-fill"></i> In Live Mode, real SMS messages will be sent and Semaphore credits will be used.</div>',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, Enable Live Mode',
            cancelButtonText: 'Cancel'
          }).then((result) => {
            if (result.isConfirmed) {
              dashboardToggleModeValue.value = 'live';
              dashboardModeToggleForm.submit();
            } else {
              dashboardModeToggle.checked = true;
            }
          });
        } else {
          // Dev mode doesn't need confirmation
          dashboardToggleModeValue.value = 'dev';
          dashboardModeToggleForm.submit();
        }
      });
    }
  });
</script>
<!-- Add this script near the end of your file, before closing </body> tag -->
<script>
function confirmEmergencyBroadcast(form) {
  // Get the message
  const message = document.getElementById('emergencyMessageField').value;
  
  if (!message.trim()) {
    Swal.fire({
      title: 'Error',
      text: 'Please enter an emergency message',
      icon: 'error'
    });
    return;
  }
  
  // Show confirmation dialog
  Swal.fire({
    title: 'Send Emergency Broadcast?',
    html: `
      <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <strong>This will send an SMS to ALL residents immediately.</strong>
      </div>
      <p><strong>Message:</strong></p>
      <p class="p-2 border bg-light">${message}</p>
      <p class="mt-3"><small>Mode: ${<?= isset($_SESSION['sms_dev_mode']) && $_SESSION['sms_dev_mode'] ? "'TESTING (No actual messages will be sent)'" : "'LIVE (Real SMS will be sent)'" ?>}</small></p>
    `,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Yes, Send Emergency Alert',
    cancelButtonText: 'Cancel'
  }).then((result) => {
    if (result.isConfirmed) {
      form.submit();
    }
  });
}
</script>
  </body>
</html>