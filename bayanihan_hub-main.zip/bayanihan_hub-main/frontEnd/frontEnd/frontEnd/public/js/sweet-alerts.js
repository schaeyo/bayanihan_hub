/**
 * SweetAlert Utilities for Bayanihan Hub
 * Provides custom styled alerts for a better user experience
 */

// Make sure SweetAlert2 is loaded
if (typeof Swal === 'undefined') {
  console.error('SweetAlert2 is not loaded. Please include the SweetAlert2 library.');
}

/**
 * Show information card details
 * @param {string} type - The type of info to show (residents, requests, etc.)
 */
function showCardInfo(type) {
  let title, text, icon;
  
  switch(type) {
    case 'residents':
      title = 'Residents Information';
      text = 'View and manage all registered residents in your barangay.';
      icon = 'info';
      break;
    case 'requests':
      title = 'Requests Information';
      text = 'These are pending requests from residents requiring your attention.';
      icon = 'info';
      break;
    case 'emergencies':
      title = 'Emergency Reports';
      text = 'View all emergency reports that have been submitted by residents.';
      icon = 'warning';
      break;
    case 'officials':
      title = 'Barangay Officials';
      text = 'List of all barangay officials with administrative access.';
      icon = 'info';
      break;
    default:
      title = 'Information';
      text = 'No specific details available.';
      icon = 'info';
  }
  
  Swal.fire({
    title: title,
    text: text,
    icon: icon,
    confirmButtonColor: '#001a4f',
    confirmButtonText: 'OK'
  });
}

/**
 * Show notification success alert
 * @param {Object} data - SMS status data
 */
function showNotificationSuccess(data) {
  let html = `<p>Notification has been successfully sent.</p>`;
  
  if (data.sms_sent) {
    if (data.sms_dev_mode) {
      html += `
        <div class="alert alert-info">
          <p><strong>Development Mode:</strong> SMS messages were simulated but not actually sent.</p>
          <p>Recipients: ${data.sms_total || 0}</p>
        </div>
      `;
    } else {
      html += `
        <div class="alert alert-info">
          <p><strong>SMS Status:</strong></p>
          <p>Successfully sent: ${data.sms_success || 0}</p>
          <p>Failed: ${data.sms_failed || 0}</p>
          <p>Total recipients: ${data.sms_total || 0}</p>
        </div>
      `;
    }
  }
  
  Swal.fire({
    title: 'Success',
    html: html,
    icon: 'success',
    confirmButtonColor: '#28a745',
    confirmButtonText: 'OK'
  });
}

/**
 * Show logout confirmation
 * @param {string} redirectUrl - URL to redirect after confirmation
 */
function showLogoutConfirmation(redirectUrl) {
  Swal.fire({
    title: 'Are you sure you want to log out?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Yes, Logout',
    cancelButtonText: 'Cancel'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = redirectUrl;
    }
  });
}

/**
 * Show emergency broadcast confirmation
 * @param {HTMLFormElement} form - The form element to submit
 */
function confirmEmergencyBroadcast(form) {
  Swal.fire({
    title: 'Send Emergency Broadcast?',
    text: 'This will immediately send SMS messages to ALL residents. Continue?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#dc3545',
    cancelButtonColor: '#6c757d',
    confirmButtonText: 'Yes, Send Emergency Alert',
    cancelButtonText: 'Cancel'
  }).then((result) => {
    if (result.isConfirmed) {
      form.submit();
    }
  });
  
  return false;
}