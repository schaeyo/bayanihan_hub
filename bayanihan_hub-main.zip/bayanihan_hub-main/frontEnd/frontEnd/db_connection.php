<?php

// Database configuration
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "bayanihan_hub"; 

// Create a connection
$con = new mysqli($host, $username, $password, $database);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
