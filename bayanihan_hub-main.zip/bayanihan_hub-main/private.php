<?php
// Include the database connection
include 'frontEnd/frontEnd/db_connection.php';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Set default values for other fields
    $username = "admin_" . substr(md5(time()), 0, 6); // Generate a username based on timestamp
    $first_name = "Admin";
    $middle_name = "";
    $last_name = "User";
    $name_extension = "";
    $phone_number = "09123456789";
    $birthdate = "1990-01-01";
    $civil_status = "Single";
    $gender = "Male";
    $occupation = "Administrator";
    $barangay = "Sta. Lucia";
    $house_address = "Barangay Hall";
    $role = "ADMIN"; // Add role as a variable
    
    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Create the admin user - use placeholder for ALL values including role
    $query = "INSERT INTO users (
                role, 
                username, 
                email, 
                password, 
                first_name, 
                middle_name, 
                last_name, 
                name_extension,
                phone_number,
                birthdate,
                civil_status,
                gender,
                occupation,
                barangay,
                house_address
            ) VALUES (
                ?, 
                ?, 
                ?, 
                ?, 
                ?, 
                ?, 
                ?, 
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?
            )";
            
    $stmt = $con->prepare($query);
    $stmt->bind_param(
        "sssssssssssssss", 
        $role,      // Add role as first parameter
        $username, 
        $email, 
        $hashed_password, 
        $first_name, 
        $middle_name, 
        $last_name, 
        $name_extension,
        $phone_number,
        $birthdate,
        $civil_status,
        $gender,
        $occupation,
        $barangay,
        $house_address
    );
    
    if ($stmt->execute()) {
        $success = "Admin account created successfully! You can now log in using:<br>Email: $email<br>Username: $username";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account - Bayanihan Hub</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0">Create Admin Account</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                            <a href="frontEnd/frontEnd/frontEnd/login/signin.php" class="btn btn-primary">Go to Login</a>
                        <?php elseif (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php else: ?>
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Password *</label>
                                    <input type="password" class="form-control" name="password" required>
                                </div>
                                
                                <div class="alert alert-info">
                                    <p><strong>Note:</strong> All other details will be automatically set with default admin values.</p>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Create Admin Account</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>