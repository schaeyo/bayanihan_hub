<?php
session_start();

// Only allow POST requests from authenticated admins
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: frontEnd/frontEnd/frontEnd/login/signin.php");
    exit;
}

// Handle mode toggle
if (isset($_POST['toggle_mode'])) {
    $_SESSION['sms_dev_mode'] = $_POST['toggle_mode'] === 'dev';
}

// Redirect back to the dashboard
header("Location: frontEnd/frontEnd/frontEnd/baranggay/admin_dashboard.php");
exit;
?>