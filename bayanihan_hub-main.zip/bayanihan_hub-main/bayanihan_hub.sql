-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 01, 2025 at 03:03 PM
-- Server version: 8.0.30
-- PHP Version: 8.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bayanihan_hub`
--

-- --------------------------------------------------------

--
-- Table structure for table `analytics_data`
--

CREATE TABLE `analytics_data` (
  `id` int NOT NULL,
  `male_population` int NOT NULL,
  `female_population` int NOT NULL,
  `occupied_residential` int NOT NULL,
  `vacant_residential` int NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `children_male` int DEFAULT '0',
  `children_female` int DEFAULT '0',
  `youth_male` int DEFAULT '0',
  `youth_female` int DEFAULT '0',
  `adults_male` int DEFAULT '0',
  `adults_female` int DEFAULT '0',
  `seniors_male` int DEFAULT '0',
  `seniors_female` int DEFAULT '0',
  `single_family_units` int DEFAULT '0',
  `multi_family_units` int DEFAULT '0',
  `apartment_units` int DEFAULT '0',
  `occupied_units` int DEFAULT '0',
  `vacant_units` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `analytics_data`
--

INSERT INTO `analytics_data` (`id`, `male_population`, `female_population`, `occupied_residential`, `vacant_residential`, `updated_at`, `children_male`, `children_female`, `youth_male`, `youth_female`, `adults_male`, `adults_female`, `seniors_male`, `seniors_female`, `single_family_units`, `multi_family_units`, `apartment_units`, `occupied_units`, `vacant_units`) VALUES
(1, 6000, 5000, 1500, 740, '2025-04-18 02:01:21', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 6000, 5000, 1500, 740, '2025-04-18 10:13:45', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 6000, 5000, 500, 740, '2025-04-19 15:48:31', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 6000, 6000, 1200, 300, '2025-04-28 03:23:57', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(5, 5000, 4900, 1200, 300, '2025-04-28 03:24:17', 500, 300, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(6, 6000, 6000, 1200, 300, '2025-04-28 03:29:31', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(7, 6000, 6000, 1200, 300, '2025-04-28 03:30:56', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(8, 6000, 6000, 1200, 300, '2025-04-28 03:35:12', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(9, 6000, 6000, 1200, 300, '2025-04-28 03:35:47', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(10, 6000, 6000, 1200, 300, '2025-04-28 03:38:29', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(11, 6000, 6000, 1200, 300, '2025-04-28 03:40:38', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(12, 6000, 6000, 1200, 300, '2025-04-28 03:42:31', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(13, 6000, 6000, 1200, 300, '2025-04-28 03:42:33', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(14, 6000, 6000, 1200, 300, '2025-04-28 03:43:13', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(15, 6000, 6000, 1200, 300, '2025-04-28 03:43:22', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(16, 6000, 6000, 1200, 300, '2025-04-28 03:43:49', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(17, 6000, 6000, 1200, 300, '2025-04-28 03:45:56', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(18, 6000, 6000, 1200, 300, '2025-04-28 03:46:15', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(19, 6000, 6000, 1200, 300, '2025-04-28 03:46:48', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0),
(20, 6000, 6000, 1200, 300, '2025-04-28 04:41:45', 1500, 1400, 1200, 1300, 2800, 2600, 500, 700, 750, 350, 400, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `file_path` varchar(255) DEFAULT NULL,
  `schedule_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `category` enum('Barangay Events','Public Notice','Emergency Alerts','Community Program') NOT NULL DEFAULT 'Barangay Events',
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `description`, `file_path`, `schedule_date`, `created_at`, `category`, `updated_at`) VALUES
(30, 'LIBRENG TULI', 'Libreng Tuli para sa mga supot na mamamayan ng qc', 'announcement/announcement_680ede315fa738.67697261.jpg', '2025-07-12', '2025-04-28 01:47:29', 'Community Program', '2025-04-28 10:05:43'),
(31, '? Viva Santa Lucia‼️', '? Happy Fiesta Sta. Lucia‼️\r\nGreetings from:\r\nRM PERFORMANCE TEAM &\r\nRM SK Team', 'announcement/announcement_680edee64d7a01.19255258.jpg', '2025-04-28', '2025-04-28 01:50:30', 'Barangay Events', NULL),
(34, 'FAMILY PLANNING', 'Ginanap ngayon March 19, 2025, ganap na 8:00 am hanggang 12:00 pm sa ating Barangay Basketball Court.\r\nIto po ay programa ng ating Coun. Joseph Visaya at Eagles Q Bagwis Fairview Quatro, Executive Eagles Club.\r\nSa pakikipagtulungan ni Kapitan Ruel S. Marpa  at Barangay Council, Quezon City Health Department at GAD Sta. Lucia. Kasamang nakiisa sina Kgd. Tess Bawag , Kgd. JaJa Galarpe , Kgd. Noeme Salonga, Kgd. Jenny Dela Torre , Secretary April Lane Banaba at Treasurer Alyssa Kaye Garduque .', 'announcement/announcement_680ee5a246d667.96922107.jpg', '2025-04-28', '2025-04-28 02:19:14', 'Barangay Events', NULL),
(35, 'EMERGENCY ALERT', 'EMERGENCY ALERT: EVACUATION ALERT: Please evacuate immediately from [ AREA ] due to [ REASON ]. Proceed to designated evacuation centers.', NULL, '2025-05-01', '2025-05-01 14:40:54', 'Emergency Alerts', NULL),
(36, 'Water Interruption Notification', 'NOTICE: Water interruption scheduled on May 7, 2025 at 10:41 AM for approximately 2 hours. pokjpkpakdpoakwdada', NULL, '2025-05-07', '2025-05-01 14:41:18', 'Public Notice', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `appointment_date` date NOT NULL,
  `message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) DEFAULT 'Pending',
  `services` enum('Barangay ID','Police Assistance','Health Services','Senior Citizen Services','Business Registration','Funeral Request','Barangay Inquiries and Requests','Event Permit','National ID Registration Assistance','Mediation / Settlement','Complaint Filing') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `name`, `email`, `phone`, `appointment_date`, `message`, `created_at`, `status`, `services`) VALUES
(1, 'son chaeyoung', 'mnavarette00@gmail.com', '', '2025-04-28', 'may loko loko', '2025-04-28 04:48:56', 'Pending', 'Barangay ID');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_reports`
--

CREATE TABLE `emergency_reports` (
  `emergency_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `name_extension` varchar(10) DEFAULT NULL,
  `report_date` date NOT NULL,
  `report_time` time NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `type_of_emergency` enum('Fire','Medical','Crime','Natural Disaster','Other') NOT NULL,
  `location` text NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `emergency_reports`
--

INSERT INTO `emergency_reports` (`emergency_id`, `first_name`, `middle_name`, `last_name`, `name_extension`, `report_date`, `report_time`, `phone_number`, `email`, `file_path`, `type_of_emergency`, `location`, `description`, `created_at`, `status`, `user_id`) VALUES
(1, 'son', 'navarette', 'chaeyoung', '', '2025-04-28', '12:48:00', '09232425857', 'mnavarette00@gmail.com', 'emergency_photos/sunog.jpg', 'Fire', 'barangay hall', 'sunog', '2025-04-28 04:48:31', 'Pending', 2);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `name_extension` varchar(10) DEFAULT NULL,
  `feedback_date` date NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `citizenship` varchar(50) NOT NULL,
  `rating` enum('5 Very Satisfied','4 Satisfied','3 Neutral','2 Dissatisfied','1 Very Dissatisfied') NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pending','Reviewed') NOT NULL DEFAULT 'Pending',
  `user_id` int NOT NULL
) ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `first_name`, `middle_name`, `last_name`, `name_extension`, `feedback_date`, `phone_number`, `email`, `citizenship`, `rating`, `comment`, `created_at`, `status`, `user_id`) VALUES
(1, 'son', 'navarette', 'chaeyoung', '', '2025-04-28', '09232425857', 'mnavarette00@gmail.com', 'korean', '5 Very Satisfied', 'nice', '2025-04-28 04:49:13', 'Pending', 2),
(2, 'son', 'navarette', 'chaeyoung', '', '2025-04-28', '09232425857', 'mnavarette00@gmail.com', 'korean', '5 Very Satisfied', 'very nice', '2025-04-28 04:54:54', 'Pending', 2),
(3, 'son', 'navarette', 'chaeyoung', '', '2025-04-28', '09232425857', 'mnavarette00@gmail.com', 'korean', '5 Very Satisfied', 'nc', '2025-04-28 04:55:34', 'Pending', 2);

-- --------------------------------------------------------

--
-- Table structure for table `incident_report`
--

CREATE TABLE `incident_report` (
  `incident_id` int NOT NULL,
  `request_id` int NOT NULL,
  `resident_name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `status` enum('APPROVED','REJECT','PENDING') NOT NULL,
  `DATE` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read') DEFAULT 'unread',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `otp`, `expires_at`, `used`, `created_at`) VALUES
(1, 4, '736398', '2025-04-25 20:25:10', 0, '2025-04-25 18:15:10'),
(2, 4, '653163', '2025-04-25 20:28:09', 0, '2025-04-25 18:18:09'),
(3, 4, '592741', '2025-04-25 20:30:33', 0, '2025-04-25 18:20:33'),
(4, 4, '643934', '2025-04-25 20:34:13', 0, '2025-04-25 18:24:13'),
(5, 4, '988438', '2025-04-25 20:36:27', 0, '2025-04-25 18:26:27'),
(6, 4, '674581', '2025-04-25 20:38:36', 0, '2025-04-25 18:28:36'),
(7, 4, '844666', '2025-04-25 20:52:28', 0, '2025-04-25 18:42:28'),
(8, 4, '843160', '2025-04-25 20:58:31', 0, '2025-04-25 18:48:31'),
(9, 4, '287832', '2025-04-25 21:03:41', 0, '2025-04-25 18:53:41'),
(10, 4, '508728', '2025-04-25 21:06:38', 0, '2025-04-25 18:56:38');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `request_id` int NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `name_extension` varchar(10) DEFAULT NULL,
  `birthdate` date NOT NULL,
  `age` int DEFAULT NULL,
  `birth_place` varchar(100) NOT NULL,
  `citizenship` varchar(50) NOT NULL,
  `civil_status` enum('Single','Married','Widowed','Divorced') NOT NULL,
  `gender` enum('Male','Female','LGBTQIA+') NOT NULL,
  `email` varchar(100) NOT NULL,
  `residence_since` date DEFAULT NULL,
  `residence_duration` int DEFAULT NULL,
  `type_of_request` enum('Barangay Clearance','Business Permit','Indigency Certificate','Other') NOT NULL,
  `valid_id_path` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `date_submitted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`request_id`, `first_name`, `middle_name`, `last_name`, `name_extension`, `birthdate`, `age`, `birth_place`, `citizenship`, `civil_status`, `gender`, `email`, `residence_since`, `residence_duration`, `type_of_request`, `valid_id_path`, `created_at`, `status`, `date_submitted`) VALUES
(1, 'son', 'navarette', 'chaeyoung', '', '1999-04-23', 26, 'korea', 'korean', 'Single', 'Male', 'mnavarette00@gmail.com', '2025-04-28', 1, 'Barangay Clearance', 'req_photos_resident/announcement.webp', '2025-04-28 04:48:03', 'Pending', '2025-04-28 12:48:03');

-- --------------------------------------------------------

--
-- Table structure for table `sms_logs`
--

CREATE TABLE `sms_logs` (
  `id` int NOT NULL,
  `message_type` varchar(50) NOT NULL,
  `message_content` text NOT NULL,
  `recipients_count` int NOT NULL DEFAULT '0',
  `success_count` int NOT NULL DEFAULT '0',
  `sent_by` int DEFAULT NULL,
  `sent_date` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sms_logs`
--

INSERT INTO `sms_logs` (`id`, `message_type`, `message_content`, `recipients_count`, `success_count`, `sent_by`, `sent_date`, `created_at`) VALUES
(14, 'test', 'message from Bayanihan Hub', 1, 1, 3, '2025-05-01 21:26:34', '2025-05-01 13:26:34'),
(15, 'test', 'message from Bayanihan Hub', 1, 1, 3, '2025-05-01 21:27:27', '2025-05-01 13:27:27'),
(16, 'test', 'makukulong ka', 1, 1, 3, '2025-05-01 21:38:21', '2025-05-01 13:38:21'),
(17, 'test', 'Test message from Bayanihan Hub', 1, 1, 3, '2025-05-01 21:39:27', '2025-05-01 13:39:27'),
(18, 'emergency', 'EMERGENCY ALERT: EVACUATION ALERT: Please evacuate immediately from [ AREA ] due to [ REASON ]. Proceed to designated evacuation centers.', 3, 3, 3, '2025-05-01 22:40:58', '2025-05-01 14:40:58'),
(19, 'utility', 'NOTICE: Water interruption scheduled on May 7, 2025 at 10:41 AM for approximately 2 hours. pokjpkpakdpoakwdada', 3, 3, 3, '2025-05-01 22:41:21', '2025-05-01 14:41:21');

-- --------------------------------------------------------

--
-- Table structure for table `sms_usage_limits`
--

CREATE TABLE `sms_usage_limits` (
  `id` int NOT NULL,
  `limit_name` varchar(50) NOT NULL,
  `current_count` int DEFAULT '0',
  `max_limit` int DEFAULT '50',
  `last_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sms_usage_limits`
--

INSERT INTO `sms_usage_limits` (`id`, `limit_name`, `current_count`, `max_limit`, `last_updated`) VALUES
(1, 'total_sms', 8, 50, '2025-05-01 22:41:21');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `role` enum('ADMIN','RESIDENT') DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `name_extension` varchar(10) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `civil_status` enum('Single','Married','Widowed','Separated','Divorced') NOT NULL,
  `gender` enum('Male','Female','LGBTQIA+') NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT 'default.jpg',
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(100) DEFAULT NULL,
  `residence_since` varchar(255) DEFAULT NULL,
  `house_address` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL,
  `show_verification` tinyint(1) DEFAULT '0',
  `verify_email` tinyint(1) DEFAULT '0',
  `verification_code` varchar(6) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `role`, `first_name`, `middle_name`, `last_name`, `name_extension`, `birthdate`, `civil_status`, `gender`, `email`, `phone_number`, `occupation`, `barangay`, `profile_photo`, `password`, `created_at`, `updated_at`, `username`, `residence_since`, `house_address`, `profile_image`, `reset_token_hash`, `reset_token_expires_at`, `show_verification`, `verify_email`, `verification_code`, `is_verified`) VALUES
(1, 'ADMIN', 'marvin', 'nabos', 'navarette', '', '2004-01-23', 'Single', 'Male', 'mnavarette45@gmail.com', '09509344458', 'student', 'Sta. Lucia', 'default.jpg', '$2y$10$IGyTlJSOGTXcYhmAUDk2Oeh6jcAwA/wDrFTRxOy2SANsKlN7/Cuqa', '2025-04-28 01:24:59', '2025-04-28 01:24:59', 'marvin45', '2024', '409 east berkely st.', 'chae1.jpg', NULL, NULL, 0, 0, NULL, NULL),
(2, 'RESIDENT', 'son', 'navarette', 'chaeyoung', '', '1999-04-23', 'Married', 'Male', 'mnavarette00@gmail.com', '09232425857', 'kpop', 'Sta. Lucia', 'default.jpg', '$2y$10$pMw/tvj0O6/eZUht/BSSK.Qg54F0KrGNWOtTdij9JrtUNZnRq20ra', '2025-04-28 04:45:30', '2025-04-28 04:45:30', 'chaey', '2020', '409 east berkely st.', 'ch.jpeg', NULL, NULL, 0, 0, NULL, NULL),
(3, 'ADMIN', 'Admin', '', 'User', '', '1990-01-01', 'Single', 'Male', 'spadev99@gmail.com', '09123456789', 'Administrator', 'Sta. Lucia', 'default.jpg', '$2y$10$DEVVjtzUATeUa4EjK01meepKSApgfB6.ZuPmKVxGvM1697FZj6.n.', '2025-04-30 17:20:03', '2025-04-30 17:20:03', 'admin_33e587', '<br /><b>Deprecated</b>:  htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated in <b>C:\\laragon\\www\\bayanihan_hub-main\\frontEnd\\frontEnd\\frontEnd\\baranggay\\accountinfo.php</b> on line <b>408</b><br />', 'Barangay Hall', '17-1500267722-banana3.jpg', NULL, NULL, 0, 0, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `analytics_data`
--
ALTER TABLE `analytics_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emergency_reports`
--
ALTER TABLE `emergency_reports`
  ADD PRIMARY KEY (`emergency_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `incident_report`
--
ALTER TABLE `incident_report`
  ADD PRIMARY KEY (`incident_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `sms_logs`
--
ALTER TABLE `sms_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sms_usage_limits`
--
ALTER TABLE `sms_usage_limits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `limit_name` (`limit_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `analytics_data`
--
ALTER TABLE `analytics_data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `emergency_reports`
--
ALTER TABLE `emergency_reports`
  MODIFY `emergency_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `request_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sms_logs`
--
ALTER TABLE `sms_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sms_usage_limits`
--
ALTER TABLE `sms_usage_limits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
